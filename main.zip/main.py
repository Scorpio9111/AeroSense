import streamlit as st
import pandas as pd
import numpy as np
import requests
import plotly.graph_objects as go
import plotly.express as px
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor  # <--- CHANGED TO RANDOM FOREST
from datetime import datetime, timedelta

# --- 1. CONFIGURATION & STYLING ---
st.set_page_config(page_title="AeroSense Enterprise", page_icon="🌍", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
    <style>
    .stApp { background: linear-gradient(to bottom right, #0f172a, #1e293b); color: #ffffff; }
    section[data-testid="stSidebar"] { background-color: #0b1120; border-right: 1px solid #334155; }
    div[data-testid="stMetric"] { background-color: rgba(15, 23, 42, 0.95); border: 1px solid rgba(148, 163, 184, 0.2); padding: 15px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3); }
    div[data-testid="stMetricLabel"] { color: #e2e8f0 !important; font-size: 1rem; }
    div[data-testid="stMetricValue"] { color: #ffffff !important; font-weight: 700; }
    h1, h2, h3, h4, h5, p, span { color: #f1f5f9 !important; font-family: 'Inter', sans-serif; }
    .high-risk { background-color: rgba(185, 28, 28, 0.2); border: 1px solid #ef4444; color: #fecaca !important; padding: 20px; border-radius: 10px; text-align: center; }
    .high-risk h1 { color: #ffffff !important; }
    </style>
    """, unsafe_allow_html=True)

# --- 2. DATA FETCHING ---
@st.cache_data(ttl=3600)
def fetch_city_rankings():
    cities = {
        "Islamabad": (33.68, 73.04), "Lahore": (31.52, 74.35),
        "Karachi": (24.86, 67.00), "Peshawar": (34.01, 71.52),
        "Quetta": (30.17, 66.97), "Multan": (30.15, 71.52),
        "New Delhi": (28.61, 77.20), "New York": (40.71, -74.00), "London": (51.50, -0.12)
    }
    results = []
    url = "https://air-quality-api.open-meteo.com/v1/air-quality"
    params = {
        "latitude": [c[0] for c in cities.values()],
        "longitude": [c[1] for c in cities.values()],
        "current": "pm2_5,pm10,nitrogen_dioxide,sulphur_dioxide,ozone,carbon_monoxide,us_aqi"
    }
    try:
        r = requests.get(url, params=params).json()
        for i, (city_name, _) in enumerate(cities.items()):
            curr = r[i]['current'] if isinstance(r, list) else r['current']
            results.append({
                "City": city_name, "AQI": curr['us_aqi'], "PM2.5": curr['pm2_5'], "PM10": curr['pm10'], 
                "NO2": curr['nitrogen_dioxide'], "SO2": curr['sulphur_dioxide'], 
                "Ozone": curr['ozone'], "CO": curr['carbon_monoxide']
            })
        return pd.DataFrame(results)
    except Exception as e:
        return pd.DataFrame()

@st.cache_data(ttl=3600)
def fetch_multivariate_data(city_name):
    cities = {
        "Islamabad": (33.68, 73.04), "Lahore": (31.52, 74.35), "Karachi": (24.86, 67.00),
        "Peshawar": (34.01, 71.52), "New York": (40.71, -74.00), "London": (51.50, -0.12)
    }
    lat, lon = cities[city_name]

    # Pollutants
    aq_url = "https://air-quality-api.open-meteo.com/v1/air-quality"
    aq_params = {"latitude": lat, "longitude": lon, "hourly": "pm2_5,pm10,nitrogen_dioxide,sulphur_dioxide,ozone,carbon_monoxide,dust", "past_days": 90}
    
    # Weather
    wx_url = "https://api.open-meteo.com/v1/forecast"
    wx_params = {"latitude": lat, "longitude": lon, "hourly": "temperature_2m,relative_humidity_2m,wind_speed_10m", "past_days": 90}

    try:
        aq_response = requests.get(aq_url, params=aq_params).json()
        wx_response = requests.get(wx_url, params=wx_params).json()

        aq_df = pd.DataFrame({
            'time': pd.to_datetime(aq_response['hourly']['time']),
            'PM2.5': aq_response['hourly']['pm2_5'], 'PM10': aq_response['hourly']['pm10'],
            'NO2': aq_response['hourly']['nitrogen_dioxide'], 'SO2': aq_response['hourly']['sulphur_dioxide'],
            'Ozone': aq_response['hourly']['ozone'], 'CO': aq_response['hourly']['carbon_monoxide'],
            'Dust': aq_response['hourly']['dust']
        })

        wx_df = pd.DataFrame({
            'time': pd.to_datetime(wx_response['hourly']['time']),
            'Temp': wx_response['hourly']['temperature_2m'],
            'Humidity': wx_response['hourly']['relative_humidity_2m'],
            'Wind': wx_response['hourly']['wind_speed_10m']
        })

        df = pd.merge(aq_df, wx_df, on='time', how='inner')

        # Regional Index
        regional_vals = []
        for c_name, c_coords in cities.items():
            if c_name != city_name:
                try:
                    r = requests.get(aq_url, params={"latitude": c_coords[0], "longitude": c_coords[1], "current": "pm2_5"}).json()
                    regional_vals.append(r['current']['pm2_5'])
                except:
                    pass
        regional_avg = np.mean(regional_vals) if regional_vals else 0
        df['Regional_Index'] = df['PM2.5'].rolling(window=24, min_periods=1).mean() * 0.8 + regional_avg * 0.2
        
        return df.dropna()
    except Exception as e:
        return pd.DataFrame()

# --- 3. RANDOM FOREST MODEL (Compatible with Python 3.13) ---
def train_multivariate_model(df, target_col):
    """
    Uses Random Forest instead of LSTM to ensure compatibility with Python 3.13.
    """
    feature_cols = [c for c in df.columns if c != 'time']
    
    # Scaling
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df[feature_cols])
    
    target_idx = feature_cols.index(target_col)
    look_back = 24
    
    if len(scaled_data) <= look_back: return None, None, None, None, None

    X, y = [], []
    for i in range(look_back, len(scaled_data)):
        # Flatten the window for Random Forest input
        window = scaled_data[i-look_back:i, :]
        X.append(window.flatten()) 
        y.append(scaled_data[i, target_idx])    
        
    X, y = np.array(X), np.array(y)
    
    # Random Forest Model (Works on all Python versions)
    model = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
    model.fit(X, y)
    
    return model, scaler, feature_cols, target_idx, look_back

# --- 4. GENAI ADVISOR ---
def generate_policy_report(city_name, peak_val, pollutant):
    thresholds = {'PM2.5': (35, 75), 'PM10': (50, 150), 'NO2': (50, 100), 'SO2': (40, 80), 'Ozone': (100, 180), 'CO': (4, 9)}
    low, high = thresholds.get(pollutant, (50, 100))
    
    if peak_val > high:
        status, color = "CRITICAL", "#ef4444"
        rec = f"**EMERGENCY ALERT:** {pollutant} levels are hazardous. Suspend outdoor activities."
    elif peak_val > low:
        status, color = "UNHEALTHY", "#f97316"
        rec = f"**Health Warning:** High {pollutant} detected. Sensitive groups should wear masks."
    else:
        status, color = "GOOD", "#22c55e"
        rec = "Air quality is within safe limits."

    return f"""
    <div style="background-color: rgba(15, 23, 42, 0.9); padding: 20px; border-left: 5px solid {color}; margin-top: 20px; border-radius: 5px;">
        <h3 style="color: {color} !important; margin: 0;">🤖 AI Advisory: {city_name}</h3>
        <p style="color: white; margin-top: 10px; font-size: 1.1em;"><b>Target: {pollutant} | Status: {status} | Peak Forecast: {peak_val:.1f}</b></p>
        <p style="color: #e2e8f0;">{rec}</p>
    </div>
    """

# --- 5. MAIN APP ---
def main():
    st.title("🌫️ AeroSense Enterprise")
    st.markdown("### Advanced Spatio-Temporal Air Quality System")
    
    st.sidebar.header("📍 Configuration")
    city = st.sidebar.selectbox("Select Region", ["Islamabad", "Lahore", "Karachi", "Peshawar", "New York", "London"])
    
    st.markdown("---")
    col_r1, col_r2 = st.columns([3, 1])
    with col_r1: st.subheader("⚠️ Regional Smog Radar")
    with col_r2: radar_metric = st.selectbox("Radar Pollutant:", ["PM2.5", "PM10", "NO2", "SO2", "Ozone", "CO"])
    
    rank_df = fetch_city_rankings()
    if not rank_df.empty:
        rank_df = rank_df.sort_values(by=radar_metric, ascending=False)
        top_city = rank_df.iloc[0]
        c1, c2 = st.columns([1, 2])
        with c1:
            st.markdown(f"""<div class="high-risk"><h3 style="color: #fca5a5 !important;">🚨 HIGHEST {radar_metric}</h3><h1>{top_city['City']}</h1><h1>{top_city[radar_metric]}</h1><p>Unit: µg/m³</p></div>""", unsafe_allow_html=True)
        with c2:
            fig_rank = px.bar(rank_df, x='City', y=radar_metric, color=radar_metric, color_continuous_scale='Reds')
            fig_rank.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_rank, use_container_width=True)

    st.markdown("---")
    st.subheader(f"📊 Deep Dive: {city}")
    
    with st.spinner(f"Aggregating Satellite & Weather Data for {city}..."):
        df = fetch_multivariate_data(city)
    
    if df.empty:
        st.error("Data source unavailable.")
        return

    curr = df.iloc[-1]
    m1, m2, m3, m4 = st.columns(4)
    with m1: st.metric("PM2.5 (Smog)", f"{curr['PM2.5']:.1f}", delta="Critical")
    with m2: st.metric("NO2 (Traffic)", f"{curr['NO2']:.1f}", delta_color="inverse")
    with m3: st.metric("Temp / Wind", f"{curr['Temp']:.1f}°C / {curr['Wind']:.1f} km/h")
    with m4: st.metric("Regional Index", f"{curr['Regional_Index']:.1f}")

    pollutant_view = st.selectbox("Select History View:", df.columns[1:-3], index=0)
    fig_hist = px.area(df, x='time', y=pollutant_view, title=f"{pollutant_view} Trends (Last 90 Days)", line_shape='spline')
    fig_hist.update_traces(line_color='#38bdf8', fillcolor='rgba(56, 189, 248, 0.2)')
    fig_hist.update_layout(template="plotly_dark", paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
    st.plotly_chart(fig_hist, use_container_width=True)

    st.markdown("---")
    st.subheader("🧠 Spatio-Temporal AI Forecast")
    
    col_f1, col_f2 = st.columns([1, 3])
    with col_f1:
        target_pollutant = st.selectbox("🎯 Target to Predict:", ["PM2.5", "PM10", "NO2", "SO2", "Ozone", "CO"])
        run_btn = st.button("Initialize Model")
        
    if run_btn:
        with st.spinner(f"Training Ensemble Model to predict {target_pollutant}..."):
            # Switched to Random Forest Function
            model, scaler, feats, target_idx, lb = train_multivariate_model(df, target_pollutant)
            
            if model:
                # Prepare Sequence
                last_seq_df = df[feats].iloc[-lb:]
                last_seq_scaled = scaler.transform(last_seq_df)
                
                # Reshape for Random Forest loop
                curr_seq = last_seq_scaled.copy() # (24, n_features)
                
                preds = []
                for _ in range(24):
                    # Flatten current 24-hour window to predict next hour
                    input_vec = curr_seq.flatten().reshape(1, -1)
                    val = model.predict(input_vec)[0]
                    preds.append(val)
                    
                    # Update Sequence: Remove first hour, Add new hour
                    # We create a new row with the last known weather (Persistence) 
                    # but update the target pollutant with our prediction
                    new_step = curr_seq[-1, :].copy() 
                    new_step[target_idx] = val 
                    
                    # Roll the array
                    curr_seq = np.vstack([curr_seq[1:], new_step])

                dummy = np.zeros((24, len(feats)))
                dummy[:, target_idx] = preds
                rescaled = scaler.inverse_transform(dummy)[:, target_idx]
                
                future_time = [df['time'].iloc[-1] + timedelta(hours=x) for x in range(1, 25)]
                fig_pred = go.Figure()
                fig_pred.add_trace(go.Scatter(x=df['time'].tail(48), y=df[target_pollutant].tail(48), name="Actual History", line=dict(color='gray')))
                fig_pred.add_trace(go.Scatter(x=future_time, y=rescaled, name="AI Forecast", line=dict(color='#f472b6', width=3, dash='dot')))
                fig_pred.update_layout(template="plotly_dark", title=f"24-Hour {target_pollutant} Prediction", paper_bgcolor='rgba(0,0,0,0)')
                st.plotly_chart(fig_pred, use_container_width=True)
                
                st.markdown(generate_policy_report(city, np.max(rescaled), target_pollutant), unsafe_allow_html=True)

if __name__ == "__main__":
    main()